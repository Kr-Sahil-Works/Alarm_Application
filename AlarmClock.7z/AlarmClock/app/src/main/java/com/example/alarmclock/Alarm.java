package com.example.alarmclock;

import java.io.Serializable;

public class Alarm implements Serializable {
    private int id;
    private int hour;
    private int minute;
    private boolean enabled;
    private String tone;
    private boolean isRepeating;
    private boolean[] repeatDays;

    public Alarm(int hour, int minute) {
        this.id = -1;
        this.hour = hour;
        this.minute = minute;
        this.enabled = true;
        this.isRepeating = false;
        this.repeatDays = new boolean[7];
    }

    public Alarm(int id, int hour, int minute, boolean enabled) {
        this.id = id;
        this.hour = hour;
        this.minute = minute;
        this.enabled = enabled;
        this.isRepeating = false;
        this.repeatDays = new boolean[7];
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getHour() { return hour; }
    public void setHour(int hour) { this.hour = hour; }

    public int getMinute() { return minute; }
    public void setMinute(int minute) { this.minute = minute; }

    public boolean isEnabled() { return enabled; }
    public void setEnabled(boolean enabled) { this.enabled = enabled; }

    public String getTone() { return tone; }
    public void setTone(String tone) { this.tone = tone; }

    public boolean isRepeating() { return isRepeating; }
    public void setRepeating(boolean repeating) { isRepeating = repeating; }

    public boolean[] getRepeatDays() { return repeatDays; }
    public void setRepeatDays(boolean[] repeatDays) { this.repeatDays = repeatDays; }

    public String getTimeString() {
        return String.format("%02d:%02d", hour, minute);
    }
} 