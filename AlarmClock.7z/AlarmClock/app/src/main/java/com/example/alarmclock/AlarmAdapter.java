package com.example.alarmclock;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.google.android.material.switchmaterial.SwitchMaterial;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;

public class AlarmAdapter extends RecyclerView.Adapter<AlarmAdapter.AlarmViewHolder> {
    private List<Alarm> alarms;
    private final OnAlarmToggleListener toggleListener;
    private final OnAlarmDeleteListener deleteListener;

    public interface OnAlarmToggleListener {
        void onAlarmToggle(Alarm alarm, boolean isEnabled);
    }

    public interface OnAlarmDeleteListener {
        void onAlarmDelete(Alarm alarm);
    }

    public AlarmAdapter(List<Alarm> alarms, OnAlarmToggleListener toggleListener, OnAlarmDeleteListener deleteListener) {
        this.alarms = alarms;
        this.toggleListener = toggleListener;
        this.deleteListener = deleteListener;
    }

    @NonNull
    @Override
    public AlarmViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.item_alarm, parent, false);
        return new AlarmViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AlarmViewHolder holder, int position) {
        Alarm alarm = alarms.get(position);
        holder.bind(alarm);
    }

    @Override
    public int getItemCount() {
        return alarms.size();
    }

    public void updateAlarms(List<Alarm> newAlarms) {
        this.alarms = newAlarms;
        notifyDataSetChanged();
    }

    class AlarmViewHolder extends RecyclerView.ViewHolder {
        private final TextView timeTextView;
        private final SwitchMaterial alarmSwitch;

        AlarmViewHolder(@NonNull View itemView) {
            super(itemView);
            timeTextView = itemView.findViewById(R.id.alarmTimeTextView);
            alarmSwitch = itemView.findViewById(R.id.alarmSwitch);

            // Setup switch listener
            alarmSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    Alarm alarm = alarms.get(position);
                    alarm.setEnabled(isChecked);
                    toggleListener.onAlarmToggle(alarm, isChecked);
                }
            });

            // Setup long click for delete
            itemView.setOnLongClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    deleteListener.onAlarmDelete(alarms.get(position));
                    return true;
                }
                return false;
            });
        }

        void bind(Alarm alarm) {
            timeTextView.setText(String.format(Locale.getDefault(), "%02d:%02d", 
                alarm.getHour(), alarm.getMinute()));
            alarmSwitch.setChecked(alarm.isEnabled());
        }
    }
} 