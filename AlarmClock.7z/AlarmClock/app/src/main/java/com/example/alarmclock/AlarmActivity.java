package com.example.alarmclock;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Calendar;
import java.util.Locale;

public class AlarmActivity extends AppCompatActivity {
    private TextView timeTextView;
    private Button saveButton;
    private Button cancelButton;
    private AlarmDatabase alarmDatabase;
    private int hour;
    private int minute;
    private int alarmId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);

        // Enable back button in action bar
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle(R.string.set_alarm);
        }

        // Initialize views
        timeTextView = findViewById(R.id.timeTextView);
        saveButton = findViewById(R.id.saveButton);
        cancelButton = findViewById(R.id.cancelButton);

        // Initialize database
        alarmDatabase = new AlarmDatabase(this);

        // Get alarm ID if editing existing alarm
        alarmId = getIntent().getIntExtra("alarm_id", -1);
        if (alarmId != -1) {
            loadAlarm();
        } else {
            // Set default time to current time
            Calendar calendar = Calendar.getInstance();
            hour = calendar.get(Calendar.HOUR_OF_DAY);
            minute = calendar.get(Calendar.MINUTE);
            updateTimeDisplay();
        }

        // Setup time picker
        timeTextView.setOnClickListener(v -> showTimePickerDialog());

        // Setup buttons
        saveButton.setOnClickListener(v -> saveAlarm());
        cancelButton.setOnClickListener(v -> finish());
    }

    private void loadAlarm() {
        Alarm alarm = alarmDatabase.getAlarm(alarmId);
        if (alarm != null) {
            hour = alarm.getHour();
            minute = alarm.getMinute();
            updateTimeDisplay();
        }
    }

    private void showTimePickerDialog() {
        TimePickerDialog timePickerDialog = new TimePickerDialog(
            this,
            (view, hourOfDay, minute) -> {
                this.hour = hourOfDay;
                this.minute = minute;
                updateTimeDisplay();
            },
            hour,
            minute,
            true
        );
        timePickerDialog.show();
    }

    private void updateTimeDisplay() {
        timeTextView.setText(String.format(Locale.getDefault(), "%02d:%02d", hour, minute));
    }

    private void saveAlarm() {
        Alarm alarm;
        if (alarmId != -1) {
            // Update existing alarm
            alarm = alarmDatabase.getAlarm(alarmId);
            if (alarm != null) {
                alarm.setHour(hour);
                alarm.setMinute(minute);
                alarmDatabase.updateAlarm(alarm);
            }
        } else {
            // Create new alarm
            alarm = new Alarm(hour, minute);
            alarmDatabase.addAlarm(alarm);
        }
        finish();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
} 